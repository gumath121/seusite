# SITE EXPRESS — Template

Template de landing page premium, responsiva e reutilizável para GitHub Pages.

## Estrutura

- `index.html` — estrutura da página
- `style.css` — visual e responsividade
- `script.js` — popula a página automaticamente
- `config.js` — **único arquivo que você normalmente precisa editar**
- `assets/` — fotos e logo

## Para criar um cliente novo

1. Duplique o projeto.
2. Troque as imagens dentro de `assets/`.
3. Abra `config.js`.
4. Edite nome, telefone, Instagram, endereço, horário, cores, produtos e fotos.
5. Faça commit/push.
6. Ative o GitHub Pages.
7. Teste celular, WhatsApp e Maps.
8. Entregue o link ao cliente.

## Destaque no título

No `slogan`, coloque uma palavra entre colchetes:

`"Sabor de [verdade], do forno para sua mesa."`

A palavra entre `[]` recebe a cor principal.

## WhatsApp

Use o número no formato:

`5515999999999`

Sem espaços, parênteses ou hífen.

## Observação

Os depoimentos do template são exemplos. Para um cliente real, substitua por avaliações reais ou remova a seção.
