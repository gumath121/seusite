document.addEventListener("DOMContentLoaded", () => {
  const c = SITE_CONFIG;

  document.documentElement.style.setProperty("--primary", c.corPrincipal || "#ff5a36");
  document.documentElement.style.setProperty("--secondary", c.corSecundaria || "#171717");

  const $ = (id) => document.getElementById(id);

  // ===== TEXTOS =====
  document.title = `${c.nome} | ${c.categoria}`;
  document.querySelector('meta[name="description"]').setAttribute(
    "content",
    c.descricao || `${c.nome} - ${c.categoria}`
  );

  $("nomeNav").textContent = c.nome;
  $("nomeFooter").textContent = c.nome;
  $("nomeCopyright").textContent = c.nome;
  $("categoria").textContent = c.categoria;
  $("slogan").innerHTML = splitHighlight(c.slogan);
  $("descricao").textContent = c.descricao;
  $("textoBotao").textContent = c.textoBotao || "Pedir pelo WhatsApp";
  $("notaHero").textContent = c.avaliacao.nota;
  $("totalHero").textContent = c.avaliacao.total;
  $("horarioHero").textContent = c.horario;
  $("notaGrande").textContent = c.avaliacao.nota;
  $("totalGrande").textContent = c.avaliacao.total;
  $("endereco").textContent = c.endereco;
  $("horario").textContent = c.horario;
  $("instagramTexto").textContent = instagramHandle(c.instagram);
  $("mapNome").textContent = c.nome;
  $("ctaDescricao").textContent = `Fale com ${c.nome} pelo WhatsApp e faça seu pedido.`;
  $("ano").textContent = new Date().getFullYear();

  // ===== IMAGENS =====
  setImage("logoNav", c.logo, c.nome);
  setImage("logoFooter", c.logo, c.nome);
  setImage("heroImage", c.hero, `${c.nome} - destaque`);

  // ===== LINKS =====
  const wa = whatsappLink(c.whatsapp, `Olá! Vim pelo site da ${c.nome} e gostaria de saber mais.`);
  $("navWhatsapp").href = wa;
  $("heroWhatsapp").href = wa;
  $("ctaWhatsapp").href = wa;
  $("floatingWhatsapp").href = wa;
  $("mapsLink").href = c.maps;
  $("footerInstagram").href = c.instagram;

  // ===== PRODUTOS =====
  const produtos = $("produtos");
  produtos.innerHTML = "";

  c.produtos.forEach((produto, index) => {
    const msg = encodeURIComponent(
      `Olá! Vim pelo site e gostaria de pedir: ${produto.nome}.`
    );

    const card = document.createElement("article");
    card.className = "product-card reveal";
    card.innerHTML = `
      <div class="product-image">
        <img src="${produto.imagem}" alt="${escapeHtml(produto.nome)}" loading="lazy">
      </div>
      <div class="product-body">
        <h3>${escapeHtml(produto.nome)}</h3>
        <p>${escapeHtml(produto.descricao)}</p>
        <div class="product-footer">
          <span class="price">${escapeHtml(produto.preco)}</span>
          <a class="product-order" href="https://wa.me/${cleanPhone(c.whatsapp)}?text=${msg}" target="_blank" rel="noopener" aria-label="Pedir ${escapeHtml(produto.nome)}">↗</a>
        </div>
      </div>
    `;
    produtos.appendChild(card);
  });

  // ===== GALERIA =====
  const galeria = $("galeriaGrid");
  galeria.innerHTML = "";
  c.galeria.forEach((img, index) => {
    const item = document.createElement("div");
    item.className = "gallery-item reveal";
    item.innerHTML = `<img src="${img}" alt="${c.nome} - foto ${index + 1}" loading="lazy">`;
    galeria.appendChild(item);
  });

  // ===== AVALIAÇÕES =====
  const reviews = $("avaliacoesGrid");
  reviews.innerHTML = "";
  c.avaliacao.depoimentos.forEach((review) => {
    const item = document.createElement("article");
    item.className = "review-card reveal";
    item.innerHTML = `
      <p>“${escapeHtml(review.texto)}”</p>
      <div>
        <div class="stars">★★★★★</div>
        <span class="review-author">${escapeHtml(review.autor)}</span>
      </div>
    `;
    reviews.appendChild(item);
  });

  // ===== ESCONDER SEÇÕES =====
  if (!c.secoes.produtos) $("destaques").style.display = "none";
  if (!c.secoes.galeria) $("galeria").style.display = "none";
  if (!c.secoes.avaliacao) $("avaliacoes").style.display = "none";
  if (!c.secoes.localizacao) $("localizacao").style.display = "none";

  // ===== ANIMAÇÕES =====
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));

  // Faz elementos criados dinamicamente entrarem na animação.
  setTimeout(() => {
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
  }, 100);
});

function cleanPhone(phone) {
  return String(phone || "").replace(/\D/g, "");
}

function whatsappLink(phone, message) {
  return `https://wa.me/${cleanPhone(phone)}?text=${encodeURIComponent(message)}`;
}

function instagramHandle(url) {
  try {
    const clean = String(url || "").replace(/\/+$/, "");
    const last = clean.split("/").pop();
    return last && last !== "instagram.com" ? `@${last.replace(/^@/, "")}` : "@instagram";
  } catch {
    return "@instagram";
  }
}

function setImage(id, src, alt) {
  const el = document.getElementById(id);
  if (!el) return;
  el.src = src;
  el.alt = alt;
}

function splitHighlight(text) {
  // Destaque opcional: escreva [palavra] para deixar uma palavra na cor da marca.
  const value = escapeHtml(text || "");
  return value.replace(/\[(.*?)\]/g, "<em>$1</em>");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
