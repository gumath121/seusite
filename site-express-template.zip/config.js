const SITE_CONFIG = {
  // ===== DADOS PRINCIPAIS =====
  nome: "Pizzaria Aurora",
  categoria: "Pizzaria • Delivery",
  slogan: "Sabor de verdade, do forno para sua mesa.",
  descricao:
    "Pizzas artesanais, ingredientes selecionados e aquele sabor que faz você pedir de novo.",

  // Use somente números, com DDI + DDD.
  whatsapp: "5515999999999",
  instagram: "https://instagram.com/",

  endereco: "Rua Exemplo, 123 • Centro • Itapetininga/SP",
  maps: "https://www.google.com/maps/search/?api=1&query=Itapetininga%20SP",
  horario: "Terça a domingo • 18h às 23h",

  // Cores da marca
  corPrincipal: "#ff5a36",
  corSecundaria: "#171717",

  // Imagens: substitua os arquivos dentro de /assets/
  logo: "assets/logo.svg",
  hero: "assets/hero.jpg",

  // ===== PRODUTOS / SERVIÇOS =====
  produtos: [
    {
      nome: "Pizza Calabresa",
      descricao: "Molho artesanal, muçarela, calabresa e cebola.",
      preco: "R$ 45,90",
      imagem: "assets/produto-1.jpg"
    },
    {
      nome: "Pizza 4 Queijos",
      descricao: "Muçarela, provolone, parmesão e gorgonzola.",
      preco: "R$ 49,90",
      imagem: "assets/produto-2.jpg"
    },
    {
      nome: "Pizza Especial",
      descricao: "Nossa combinação especial para quem quer surpreender.",
      preco: "R$ 54,90",
      imagem: "assets/produto-3.jpg"
    }
  ],

  galeria: [
    "assets/galeria-1.jpg",
    "assets/galeria-2.jpg",
    "assets/galeria-3.jpg",
    "assets/galeria-4.jpg"
  ],

  avaliacao: {
    nota: "5,0",
    total: "120 avaliações",
    depoimentos: [
      {
        texto: "Atendimento excelente e a pizza chegou perfeita.",
        autor: "Cliente verificado"
      },
      {
        texto: "Massa muito boa e ingredientes de qualidade. Recomendo!",
        autor: "Cliente verificado"
      },
      {
        texto: "Virou meu lugar favorito para pedir pizza.",
        autor: "Cliente verificado"
      }
    ]
  },

  // Altere para true quando quiser esconder determinada seção
  secoes: {
    produtos: true,
    galeria: true,
    avaliacao: true,
    localizacao: true
  },

  // Texto do botão principal
  textoBotao: "Pedir pelo WhatsApp"
};
